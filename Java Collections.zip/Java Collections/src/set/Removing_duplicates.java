package set;

public class Removing_duplicates 
{
		
		// No need to remove duplicate values as Set by default allows only unique values to be put into it 
	

}
