package class_1.FirstProgram;

public class Example_Method_DumbAssistant 
{
	public static void main(String[] args) 
	{
		add(); // calling method add()
	}
	
	public static void add()
	{
		int a=10,b=20,Sum;
		Sum = a + b ;
		System.out.println("Sum is " + Sum);
	}

}
