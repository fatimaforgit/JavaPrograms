package com.nopcommerce.demo.ui;

public class WishlistPage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
