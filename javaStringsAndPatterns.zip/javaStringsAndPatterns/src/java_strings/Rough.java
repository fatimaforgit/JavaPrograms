package java_strings;
//Write a Java program to find first non repeated character in a string.
public class Rough {

	public static void main(String[] args) 
	{
		String givenString = "Testing Automation";
		
		String s = givenString.substring(0, 4);
		String s1 = givenString.substring(4);
		
		System.out.println(s);
		System.out.println(s1);
	}
		
		
		

}

