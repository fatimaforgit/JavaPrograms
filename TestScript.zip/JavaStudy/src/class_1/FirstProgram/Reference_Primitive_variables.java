package class_1.FirstProgram;

public class Reference_Primitive_variables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
