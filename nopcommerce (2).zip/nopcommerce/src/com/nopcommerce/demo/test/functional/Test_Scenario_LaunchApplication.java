package com.nopcommerce.demo.test.functional;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

public class Test_Scenario_LaunchApplication {
  @Test
  public void f() {
  }
  @BeforeMethod
  public void beforeMethod() {
  }

}
