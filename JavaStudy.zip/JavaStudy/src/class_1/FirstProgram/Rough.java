package class_1.FirstProgram;

import java.io.File;

public class Rough
{
	public static void main(String[] args) 
	{
		
		File f= new File("D:\\Java\\java.exe");
	}
	
}

