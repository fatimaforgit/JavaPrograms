package class_1.FirstProgram;

// how to make a variable point to its location/reference not its data/value

public class Reference_Primitive_Types_Variables 
{

	public static void main(String[] args) 
	{
		ChangesMade c=new ChangesMade();

	}

}

class ChangesMade
{
	String beforeConversion="Abrahim";
	String afterConversion="Ibrahim";
	System.out.println("Name before conversion " + beforeConversion);
	System.out.println("Name before conversion " + beforeConversion);
}


