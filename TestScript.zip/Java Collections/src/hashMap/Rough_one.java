package hashMap;

public class Rough_one {

	public static void main(String[] args) 
	{
		Rough r = new Rough();
		int sum = r.final_;
		sum=sum+1;
		System.out.println(sum);
	

	}

}
