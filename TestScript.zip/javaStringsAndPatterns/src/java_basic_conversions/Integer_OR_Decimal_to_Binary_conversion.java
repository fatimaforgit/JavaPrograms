package java_basic_conversions;

public class Integer_OR_Decimal_to_Binary_conversion 
{

	public static void main(String[] args) 
	{
		int number=4;
		System.out.println(Integer.toBinaryString(number));
		System.out.println(Integer.toHexString(number));
		System.out.println(Integer.toOctalString(number));
		
	}

}
