package com.nopcommerce.demo.ui;

public class LogoutPage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
