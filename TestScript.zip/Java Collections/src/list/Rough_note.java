package list;

import hashMap.Rough;

public class Rough_note extends Rough
{
	public static void main(String[] args) 
	{

		String s = "ads fsdg";
		String str[] = s.split("\s");

		System.out.println(str);
	}

}





