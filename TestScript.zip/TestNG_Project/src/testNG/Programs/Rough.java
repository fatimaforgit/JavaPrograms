package testNG.Programs;
import org.junit.Assert;
import org.testng.annotations.Test;

public class Rough 
{
	@Test
	public void validateTwoNumbers()
	{
		
	
		
		
		
	}
}
 