package java_patterns;

import java.util.Scanner;

public class Diamond_Pattern_1 
{
	public static void main(String[] args) 	
	{
		
		
	}

}
