package class_1.FirstProgram;

public class Example_Methods 
{

	public static void main(String[] args) 
	{
		add(); //calling method add()
		
	}
	
	public static void add()
	{
		int x=10;
		int y=20;
		int result=x+y;
		System.out.println("Result is " + result);
	}
}




		
		

	