package class_1.FirstProgram;

public class Example_Method_CleverAssistant 
{
	public static void main(String[] args) 
	{
		add(1,20); // calling method add()
	}
	
	public static void add(int a, int b)
	{
		int Sum;
		Sum = a + b ;
		System.out.println("Sum is " + Sum);
	}

}
