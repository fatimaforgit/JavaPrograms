

//Addition of two variables

public class Addition {

	public static void main(String[] args) {
		
		int x=10;
		int y=20;
		int result=x+y;
		
		System.out.println("Result is " + result);

	}

}



/*
*good to start
*/
