package SeleniumTraining;

public class Locators_in_selenium 
{

	public static void main(String[] args) 
	{

		
	}

}
