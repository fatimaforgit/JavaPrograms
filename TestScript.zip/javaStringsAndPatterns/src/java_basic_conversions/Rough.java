package java_basic_conversions;

import java.util.Scanner;

public class Rough 
{

	public static void main(String[] args) 
	{
//		String s= "name is ";
		StringBuffer sb = new StringBuffer("name is ");
		String givenString = "is";
		for(int i=1;i<=sb.length();i++)
		{
			sb.charAt(i);
		}
	
		
		
		
	}

}
