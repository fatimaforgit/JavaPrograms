package class_1.FirstProgram;

// Program to reverse a given string

public class ReverseAstringProgram 
{

	public static void main(String[] args) 
	{
		
		somestring();
		System.out.println(somestring().length());
	

	}
	public static String somestring()
	{
		String str = "abc" ;
		return str ;
	}


}

